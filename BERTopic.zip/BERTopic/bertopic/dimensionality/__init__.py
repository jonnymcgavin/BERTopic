from ._base import BaseDimensionalityReduction

__all__ = [
    "BaseDimensionalityReduction",
]
