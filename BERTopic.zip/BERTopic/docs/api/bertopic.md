# `BERTopic`

::: bertopic._bertopic.BERTopic
