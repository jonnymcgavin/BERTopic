# `Vectorizers`

::: bertopic.vectorizers._online_cv.OnlineCountVectorizer
