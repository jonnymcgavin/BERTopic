# `BaseDimensionalityReduction`

::: bertopic.dimensionality._base.BaseDimensionalityReduction
