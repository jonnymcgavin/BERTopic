# `Plotting`

::: bertopic.plotting
