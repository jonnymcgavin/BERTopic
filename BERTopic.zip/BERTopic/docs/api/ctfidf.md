# `c-TF-IDF`

::: bertopic.vectorizers.ClassTfidfTransformer
