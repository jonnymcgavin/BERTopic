# `Representations`

::: bertopic.representation
