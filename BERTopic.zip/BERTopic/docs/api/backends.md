# `Backends`

::: bertopic.backend
