# `Barchart`

::: bertopic.plotting._barchart.visualize_barchart
