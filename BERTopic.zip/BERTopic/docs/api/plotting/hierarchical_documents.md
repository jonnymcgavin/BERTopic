# `Hierarchical Documents`

::: bertopic.plotting._hierarchical_documents.visualize_hierarchical_documents
