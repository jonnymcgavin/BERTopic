# `Documents with DataMapPlot`

::: bertopic.plotting._datamap.visualize_document_datamap
