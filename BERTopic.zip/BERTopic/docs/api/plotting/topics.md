# `Topics`

::: bertopic.plotting._topics.visualize_topics
